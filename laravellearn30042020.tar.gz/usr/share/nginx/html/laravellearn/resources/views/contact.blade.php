@extends ('layout')

@section ('content')
    <h1>Hello Laracasts!</h1>

@endsection

