<?php $__env->startSection('content'); ?>

    <div id="wrapper">
        <div id="page" class="container">

            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		        <div id="content">
			    <div class="title">
                    <h2>
                        <a href="<?php echo e($article->path()); ?>">
                            <?php echo e($article->title); ?>

                        </a>
                    </h2>
                </div>

				    <p>
                        <img
                        src="images/banner.jpg"
                        alt=""
                        class="image image-full"
                        />
                    </p>

            <?php echo $article->excerpt; ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <p>No Relevant Articles yet. </p>
         <?php endif; ?>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/laravellearn/resources/views/articles/index.blade.php ENDPATH**/ ?>