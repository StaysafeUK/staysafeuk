<?php $__env->startSection('content'); ?>
<div id="header-wrapper">

</div>
    <div id="wrapper">
	    <div id="page" class="container">
		    <div id="content">
		    	<div class="title">

				    <h2> <?php echo e($article->title); ?></h2>
				    <span class="byline"><?php echo e($article->excerpt); ?> </span> </div>
			    <p><img src="/images/banner.jpg" alt="" class="image image-full" /></p>
                </div>

                {<?php echo $article->body; ?>}

                <p style="margin-top: 1em">
                 
                  
                 
                </p>

	        </div>

	    </div>
    </div>

    <div id="copyright" class="container">
	    <p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/laravellearn/resources/views/articles/show.blade.php ENDPATH**/ ?>